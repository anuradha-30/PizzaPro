package com.pack.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Customer")
public class Customer {
	private Customer customerOrder;
	public Customer getCustomerOrder() {
		return customerOrder;
	}
	public void setCustomerOrder(Customer customerOrder) {
		this.customerOrder = customerOrder;
	}
	@Id
	@GeneratedValue
	@Column(name="customerid")
	private int customerid;
	@Column(name="customername")
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getPhoneno() {
	return phoneno;
}
public void setPhoneno(int phoneno) {
	this.phoneno = phoneno;
}
private String customername;
@Column(name="address")
private String address;
@Column(name="phoneno")
private int phoneno;
}
