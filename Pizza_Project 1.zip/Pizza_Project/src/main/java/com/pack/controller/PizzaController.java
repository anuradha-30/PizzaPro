package com.pack.controller;

import java.util.HashMap;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Customer;
import com.pack.util.Util;
import com.pack.model.LoginUser;
import com.pack.service.PizzaOrderService;
import com.pack.model.Pizzaorder;
@Controller
public class PizzaController {
@Autowired
private PizzaOrderService pizzaService;

@Autowired
private Pizzaorder pizzaOrd;

@Autowired
private Customer customer;
HashMap hm=new HashMap();

@RequestMapping("/UtilController")
public String getToppings(Model m)
{
	System.out.println("into util controller");
	hm=Util.getToppings();
	System.out.println("hm "+hm);
	m.addAttribute("pizzaToppings",hm);
	m.addAttribute("customer",new Customer());
	return "placeorder";
}

@RequestMapping(value="/saveOrderController")
public String saveOrder(@RequestParam("topping") int ptopping,Model m,@Valid @ModelAttribute("customer") Customer customer,BindingResult res)
{
System.out.println("into save order");
int pid=pizzaService.placeOrder(customer,pizzaOrd,ptopping);
m.addAttribute("pid",pid);
if(res.hasErrors())
{
	m.addAttribute("pizzaToppings",hm);
	return "placeOrder";
}
else 
	return "success";
}



@RequestMapping("login")
public String getlogin(Model m)
{
	
	m.addAttribute("user", new LoginUser());
	return "login";
}
@RequestMapping(value="validate")
public String validate(@Valid @ModelAttribute("user")LoginUser u,
		BindingResult result,Model m)
{
	 if (result.hasErrors())
		 {

		  return "login";
		 }
 else
 {
		  
  return "Homepage";
	}
}
}


